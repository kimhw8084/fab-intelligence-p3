import { useEffect, useMemo, useState } from "react";
import { SpatialMapRenderer } from "./SpatialMapRenderer";
import type { SpatialMapV2 } from "../../contracts/spatial-map.v2";

type Capability = { status?: string; [key: string]: unknown };
type Evidence = {
  status: string;
  investigation_id: string;
  claims: Array<{ statement: string; category?: string; certainty?: string; method?: string }>;
  limitations: string[];
  sources: Array<{ id: string; source_hash: string; grain: string; source_version: string; approved_semantic_version: string }>;
  provenance: { input_sha256?: string; mcp_workflow?: { bounded_reads?: Array<Record<string, unknown>>; [key: string]: unknown }; [key: string]: unknown };
  artifacts: Array<{ kind: string; result: Record<string, Capability> }>;
};
type ModuleResult = {
  contract_version: string;
  product_id: "p3";
  capabilities: string[];
  source_preview: { status: string; permission: string; semantic_version: string; grain: string; metric: string; unit: string; scope: string; time_window: string; modality: string; coverage: Record<string, number>; [key: string]: unknown };
  evidence: Evidence;
  spatial_map: SpatialMapV2;
  suite_compatibility: { contract_version: string; status: string; reason: string | null };
  export: { format: string; sha256: string; canonicalization: string; canonical_json: string };
  export_content: Record<string, unknown>;
};

const CAPABILITY_NAMES: Record<string, string> = {
  C01: "Spatial fingerprint", C02: "Process-step evolution", C03: "Spatial-to-quality association",
  C04: "Spatial anomaly review", C05: "Historical analogs",
};
const RESULTS: Record<string, string> = {
  C01: "fingerprint", C02: "evolution", C03: "quality_association", C04: "anomaly", C05: "similarity",
};
const PLANS = ["SYN-WF-CURRENT", "SYN-WF-PREVIOUS", "SYN-WF-BASELINE", "SYN-WF-HISTORY", "SYN-WF-ASSOCIATION"];

export function App() {
  const [sourceMode, setSourceMode] = useState("synthetic");
  const [planText, setPlanText] = useState(PLANS.join(", "));
  const [timeStart, setTimeStart] = useState("2026-01-01T00:00:00Z");
  const [timeEnd, setTimeEnd] = useState("2026-02-01T00:00:00Z");
  const [sourceModes, setSourceModes] = useState(["synthetic"]);
  const [result, setResult] = useState<ModuleResult | null>(null);
  const [selected, setSelected] = useState("C01");
  const [state, setState] = useState<"IDLE" | "LOADING" | "CANCELLED" | "ERROR" | "REFUSED">("IDLE");
  const [message, setMessage] = useState("Ready. Synthetic source is isolated and uses no company data.");
  const [activeRequest, setActiveRequest] = useState<string | null>(null);
  const [duration, setDuration] = useState<number | null>(null);

  useEffect(() => {
    fetch("/api/status").then((response) => response.json()).then((body: { source_modes?: string[] }) => {
      if (Array.isArray(body.source_modes)) setSourceModes(body.source_modes);
    }).catch(() => setMessage("Local host status is unavailable; check the server and retry."));
  }, []);

  const selectedResult = useMemo(() => {
    const key = RESULTS[selected];
    return result?.evidence.artifacts.find((item) => item.kind === "p3_analysis")?.result[key] ?? null;
  }, [result, selected]);

  async function investigate() {
    const requestId = crypto.randomUUID();
    setActiveRequest(requestId);
    setState("LOADING");
    setMessage("Discovering approved tools and reading bounded source rows through the MCP SDK…");
    setResult(null);
    const started = performance.now();
    try {
      const response = await fetch("/api/investigate", {
        method: "POST", headers: { "Content-Type": "application/json", "X-Analysis-Id": requestId },
        body: JSON.stringify({ source_mode: sourceMode, plan_ids: planText.split(",").map((item) => item.trim()).filter(Boolean), time_start: timeStart, time_end: timeEnd, top_k: 5 }),
      });
      const body = await response.json();
      setDuration(Math.round(performance.now() - started));
      if (!response.ok) {
        setState(body.status === "CANCELLED" ? "CANCELLED" : body.status === "REFUSED" ? "REFUSED" : "ERROR");
        setMessage(body.reason ?? body.error ?? "The investigation failed. Correct the request or retry.");
        return;
      }
      setResult(body as ModuleResult);
      setState("IDLE");
      setMessage(`Investigation completed in ${Math.round(performance.now() - started)} ms. Evidence is synthetic or read-only unqualified.`);
    } catch {
      setDuration(Math.round(performance.now() - started));
      setState("ERROR");
      setMessage("The local host could not complete the request. Check its status and retry.");
    } finally {
      setActiveRequest(null);
    }
  }

  async function cancel() {
    if (!activeRequest) return;
    setMessage("Cancellation requested. Waiting for the bounded read to stop…");
    try {
      await fetch("/api/cancel", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ request_id: activeRequest }) });
    } catch {
      setMessage("Cancellation could not reach the local host. The bounded MCP call still has its configured timeout.");
    }
  }

  function exportEvidence() {
    if (!result) return;
    const payload = result.export.canonical_json;
    const blob = new Blob([payload], { type: "application/json" });
    const url = URL.createObjectURL(blob);
    const anchor = document.createElement("a");
    anchor.href = url;
    anchor.download = `p3-investigation-${result.evidence.investigation_id}.json`;
    anchor.click();
    URL.revokeObjectURL(url);
    setMessage(`Evidence export saved. Canonical SHA-256: ${result.export.sha256}`);
  }

  const map = result?.spatial_map;
  const selectedStatus = selectedResult?.status ?? "NOT_AVAILABLE";
  return <main className="app-shell">
    <header className="topbar">
      <div className="brand"><span className="brand-mark" aria-hidden="true">F</span><div><p className="eyebrow">FAB INTELLIGENCE · INDEPENDENT PRODUCT</p><h1>Spatial &amp; Yield Intelligence</h1></div></div>
      <span className="qualification-badge">Company qualification pending</span>
    </header>

    <section className="investigation-control" aria-labelledby="investigation-title">
      <div><p className="eyebrow">INVESTIGATION SETUP</p><h2 id="investigation-title">Choose a source and run C01–C05</h2></div>
      <div className="control-grid">
        <label>Source mode<select value={sourceMode} onChange={(event) => { setSourceMode(event.target.value); setPlanText(event.target.value === "synthetic" ? PLANS.join(", ") : ""); }}>
          {sourceModes.map((mode) => <option key={mode} value={mode}>{mode === "synthetic" ? "Synthetic MCP demonstration" : "Configured read-only MCP"}</option>)}
        </select></label>
        <label className="wide">Approved plan identifiers <textarea rows={2} value={planText} onChange={(event) => setPlanText(event.target.value)} aria-describedby="plan-help" /></label>
        <label>Time start <input value={timeStart} onChange={(event) => setTimeStart(event.target.value)} /></label>
        <label>Time end <input value={timeEnd} onChange={(event) => setTimeEnd(event.target.value)} /></label>
      </div>
      <p id="plan-help" className="field-help">Use identifiers from the active MCP configuration. Synthetic mode supplies a fixed demonstration workflow.</p>
      <div className="action-row">
        <button className="primary" onClick={() => void investigate()} disabled={state === "LOADING" || !planText.trim()}>Run investigation</button>
        {state === "LOADING" && <button className="secondary" onClick={() => void cancel()}>Cancel</button>}
        {duration !== null && <span className="duration">Last request: {duration} ms</span>}
      </div>
      <p className={`live-message ${state.toLowerCase()}`} role={state === "ERROR" || state === "REFUSED" ? "alert" : "status"} aria-live="polite">{message}</p>
    </section>

    {result && map ? <>
      <section className="summary-row" aria-label="Investigation summary">
        <div><span>Wafer</span><strong>{map.wafer_id}</strong><small>{map.product_id} · {map.step_id ?? "Step not supplied"}</small></div>
        <div><span>Measurement</span><strong>{map.metric}</strong><small>{map.measurement_unit} · {map.modality.replaceAll("_", " ")}</small></div>
        <div><span>Observed sites</span><strong>{map.sampling.observation_count}</strong><small>{map.sampling.explicit_missing_value_count} explicitly missing · no interpolation</small></div>
        <div><span>Evidence</span><strong>{result.evidence.status}</strong><small>{result.evidence.provenance.mcp_workflow?.bounded_reads?.length ?? 0} bounded reads</small></div>
      </section>

      <section className="work-area">
        <section className="panel spatial-panel" aria-labelledby="map-title">
          <div className="panel-heading"><div><p className="eyebrow">MEASURED OBSERVATIONS</p><h2 id="map-title">Wafer map</h2></div><span className="quiet-tag">{map.sampling.coverage_fraction === undefined ? "Coverage denominator unavailable" : `${(map.sampling.coverage_fraction * 100).toFixed(1)}% declared coverage`}</span></div>
          {map.coordinates_verified ? <SpatialMapRenderer model={map} /> : <p role="status">Coordinates are unverified. The spatial plot is withheld; the typed observation table remains available.</p>}
          <p className="chart-caption">Only measured sites are plotted. Numeric values use a continuous scale; categories and defect events retain their original types.</p>
          <details open><summary>Accessible typed observations ({map.observations.length})</summary>
            <div className="table-scroll"><table><caption>{map.metric} ({map.measurement_unit}) · wafer {map.wafer_id} · input and rendered counts reconcile</caption>
              <thead><tr><th scope="col">Site</th><th scope="col">X ({map.coordinate_unit})</th><th scope="col">Y ({map.coordinate_unit})</th><th scope="col">Kind</th><th scope="col">Value</th><th scope="col">Type</th></tr></thead>
              <tbody>{map.observations.map((row, index) => <tr key={`${row.site_id}-${index}`}>
                <th scope="row">{row.site_id}</th><td>{row.x}</td><td>{row.y}</td><td>{row.observation_kind.replaceAll("_", " ")}</td>
                <td>{row.observation_kind === "MISSING_MEASUREMENT" ? "Missing" : row.observation_kind === "DEFECT_EVENT" && row.value === null ? "Unlabeled event" : String(row.value)}</td><td>{row.value_type}</td>
              </tr>)}</tbody>
            </table></div>
          </details>
        </section>

        <section className="panel capability-panel" aria-labelledby="cap-title">
          <div className="panel-heading"><div><p className="eyebrow">SCIENTIFIC REVIEW</p><h2 id="cap-title">C01–C05 capabilities</h2></div></div>
          <div className="capability-tabs" role="tablist" aria-label="P3 scientific capabilities">
            {Object.entries(CAPABILITY_NAMES).map(([id, label]) => {
              const key = RESULTS[id];
              const status = result.evidence.artifacts.find((item) => item.kind === "p3_analysis")?.result[key]?.status ?? "NOT_AVAILABLE";
              return <button role="tab" aria-selected={selected === id} aria-controls="capability-detail" key={id} onClick={() => setSelected(id)}><b>{id}</b><span>{label}</span><em>{status}</em></button>;
            })}
          </div>
          <div id="capability-detail" role="tabpanel" aria-live="polite">
            <h3>{selected} · {CAPABILITY_NAMES[selected]}</h3><p className="status-line">Status: <strong>{selectedStatus}</strong></p>
            {selectedResult ? <pre className="result-json">{JSON.stringify(selectedResult, null, 2)}</pre> : <p>No result supplied for this capability.</p>}
          </div>
          <details className="provenance"><summary>Source evidence and provenance</summary>
            <p>Read-only scope: {String(result.evidence.provenance.mcp_workflow?.permission_scope ?? "not supplied")}</p>
            <p>Semantic mapping: {map.provenance.semantic_version} · source snapshot {map.provenance.source_version}</p>
            <p>Source hash: <code>{map.provenance.source_hash}</code></p>
            <p>Host compatibility adapter: {result.suite_compatibility.status}{result.suite_compatibility.reason ? ` — ${result.suite_compatibility.reason}` : ""}</p>
            <details><summary>Bounded read audit</summary><pre className="result-json">{JSON.stringify(result.evidence.provenance.mcp_workflow?.bounded_reads ?? [], null, 2)}</pre></details>
            <details><summary>All scientific limitations</summary><ul>{result.evidence.limitations.map((item, index) => <li key={index}>{item}</li>)}</ul></details>
          </details>
          <button className="secondary export-button" onClick={exportEvidence}>Export reproducible evidence</button>
          <p className="hash-line">Export SHA-256: <code>{result.export.sha256}</code></p>
        </section>
      </section>
    </> : <section className="empty-state"><div aria-hidden="true">◎</div><h2>Start a spatial investigation</h2><p>Run the synthetic MCP workflow to inspect measured coverage, C01–C05 findings, source provenance, and an exportable evidence envelope.</p></section>}
    <footer className="page-footer">P3 reference host · local loopback only · synthetic MCP data or explicitly configured read-only source · internal qualification remains pending</footer>
  </main>;
}
