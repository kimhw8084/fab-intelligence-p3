import { afterEach, describe, expect, it, vi } from "vitest";
import { cleanup, fireEvent, render, screen, waitFor, within } from "@testing-library/react";
import "@testing-library/jest-dom/vitest";
import { App } from "./App";

vi.mock("./SpatialMapRenderer", () => ({
  SpatialMapRenderer: ({ model }: { model: { wafer_id: string } }) => <div role="img" aria-label={`Measured wafer observations for ${model.wafer_id}.`} />,
}));

const moduleResult = {
  contract_version: "p3-reference-module.v2", product_id: "p3", capabilities: ["C01", "C02", "C03", "C04", "C05"],
  source_preview: { status: "SYNTHETIC_ONLY", permission: "Synthetic only", semantic_version: "SYN-1", grain: "wafer site", metric: "die_bin", unit: "category", scope: "W-1", time_window: "2026-01", modality: "die_bin_categorical", coverage: { observations: 4 } },
  evidence: { status: "PARTIAL", investigation_id: "SYN-1", claims: [], limitations: ["Synthetic only."], sources: [], provenance: { input_sha256: "abc", mcp_workflow: { permission_scope: "read_only", bounded_reads: [] } }, artifacts: [{ kind: "p3_analysis", result: {
    fingerprint: { status: "PARTIAL", pattern: "categorical" }, evolution: { status: "INCONCLUSIVE" }, quality_association: { status: "INCONCLUSIVE" }, anomaly: { status: "INCONCLUSIVE" }, similarity: { status: "INCONCLUSIVE" },
  } }] },
  spatial_map: { schema_version: "fab-spatial-map.v2", wafer_id: "W-1", lot_id: "L-1", product_id: "P-1", step_id: "ETCH", step_instance_id: "ETCH-1", measured_at: "2026-01-01T00:00:00Z", coordinates_verified: true, coordinate_unit: "mm", metric: "die_bin", measurement_unit: "category", modality: "die_bin_categorical", geometry: { coordinate_system: "wafer_xy_v1", coordinate_unit: "mm", origin: { x: 0, y: 0 }, radius: 1, orientation_deg: 0 }, sampling: { mask_id: "M-1", observation_count: 4, numeric_measurement_count: 0, categorical_measurement_count: 2, defect_event_count: 0, explicit_missing_value_count: 2, coverage_basis: "DECLARED_EXPECTED_SITE_COUNT", expected_site_count: 8, coverage_fraction: 0.5 }, observations: [
    { site_id: "die-1", x: 0.1, y: 0.1, observation_kind: "CATEGORICAL_MEASUREMENT", value: 2, value_type: "number" },
    { site_id: "die-2", x: 0.2, y: 0.1, observation_kind: "CATEGORICAL_MEASUREMENT", value: "PASS", value_type: "string" },
    { site_id: "die-3", x: 0.3, y: 0.1, observation_kind: "MISSING_MEASUREMENT", value: null, value_type: "null" },
    { site_id: "die-4", x: 0.4, y: 0.1, observation_kind: "DEFECT_EVENT", value: null, value_type: "null" },
  ], interpolation: "none", provenance: { source_id: "SYN", source_version: "SNAP-1", semantic_version: "SYN-1", source_hash: "a".repeat(64), grain: "wafer site" } },
  suite_compatibility: { contract_version: "suite-ui-module.v1", status: "COMPATIBLE", reason: null },
  export: { format: "fab-intelligence-investigation.v1", sha256: "b".repeat(64), canonicalization: "canonical", canonical_json: "{}" },
  export_content: {},
};

afterEach(() => { cleanup(); vi.unstubAllGlobals(); vi.restoreAllMocks(); });

describe("P3 independent reference workflow", () => {
  it("preserves typed observations, exposes capability detail, provenance, and export", async () => {
    const fetchMock = vi.fn(async (input: RequestInfo | URL, _init?: RequestInit) => {
      if (String(input) === "/api/status") return new Response(JSON.stringify({ source_modes: ["synthetic"] }));
      return new Response(JSON.stringify(moduleResult), { status: 200 });
    });
    vi.stubGlobal("fetch", fetchMock);
    vi.stubGlobal("crypto", { randomUUID: () => "6c8690f0-906d-46a5-a63f-e380a8b00002" });
    const click = vi.spyOn(HTMLAnchorElement.prototype, "click").mockImplementation(() => undefined);
    render(<App />);
    fireEvent.click(screen.getByRole("button", { name: "Run investigation" }));
    await screen.findByRole("table", { name: /die_bin \(category\).*W-1/ });
    const table = screen.getByRole("table", { name: /die_bin \(category\).*W-1/ });
    expect(within(table).getAllByRole("row")).toHaveLength(5);
    expect(within(table).getByText("2")).toBeInTheDocument();
    expect(within(table).getByText("number")).toBeInTheDocument();
    expect(within(table).getByText("PASS")).toBeInTheDocument();
    expect(within(table).getByText("Missing")).toBeInTheDocument();
    expect(within(table).getByText("Unlabeled event")).toBeInTheDocument();
    fireEvent.click(screen.getByRole("tab", { name: /C02/ }));
    expect(screen.getByRole("tabpanel")).toHaveTextContent("C02 · Process-step evolution");
    fireEvent.click(screen.getByText("Source evidence and provenance"));
    expect(screen.getByText(/Source hash:/)).toBeInTheDocument();
    fireEvent.click(screen.getByRole("button", { name: "Export reproducible evidence" }));
    expect(click).toHaveBeenCalledOnce();
    await waitFor(() => expect(screen.getByText(/Canonical SHA-256/)).toBeInTheDocument());
    const investigateCall = fetchMock.mock.calls.find((call) => String(call[0]) === "/api/investigate");
    expect(investigateCall).toBeDefined();
    expect(JSON.parse(String((investigateCall?.[1] as RequestInit).body)).plan_ids).toHaveLength(5);
  });

  it("shows refusal and recovery without displaying stale findings", async () => {
    const fetchMock = vi.fn(async (input: RequestInfo | URL, _init?: RequestInit) => {
      if (String(input) === "/api/status") return new Response(JSON.stringify({ source_modes: ["synthetic"] }));
      return new Response(JSON.stringify({ status: "REFUSED", reason: "Reviewed source permission failed." }), { status: 403 });
    });
    vi.stubGlobal("fetch", fetchMock);
    vi.stubGlobal("crypto", { randomUUID: () => "6c8690f0-906d-46a5-a63f-e380a8b00003" });
    render(<App />);
    fireEvent.click(screen.getByRole("button", { name: "Run investigation" }));
    expect(await screen.findByRole("alert")).toHaveTextContent("Reviewed source permission failed.");
    expect(screen.getByText("Start a spatial investigation")).toBeInTheDocument();
  });

  it("reports cancellation distinctly and allows a clean retry", async () => {
    let investigationCount = 0;
    const fetchMock = vi.fn(async (input: RequestInfo | URL, _init?: RequestInit) => {
      if (String(input) === "/api/status") return new Response(JSON.stringify({ source_modes: ["synthetic"] }));
      investigationCount += 1;
      if (investigationCount === 1) return new Response(JSON.stringify({
        status: "CANCELLED", reason: "Investigation cancelled. No partial analysis was accepted; you can correct the request or retry.",
      }), { status: 409 });
      return new Response(JSON.stringify(moduleResult), { status: 200 });
    });
    vi.stubGlobal("fetch", fetchMock);
    vi.stubGlobal("crypto", { randomUUID: () => "6c8690f0-906d-46a5-a63f-e380a8b00004" });
    render(<App />);
    fireEvent.click(screen.getByRole("button", { name: "Run investigation" }));
    expect(await screen.findByText(/Investigation cancelled\. No partial analysis was accepted/)).toBeInTheDocument();
    expect(screen.getByRole("button", { name: "Run investigation" })).toBeEnabled();
    fireEvent.click(screen.getByRole("button", { name: "Run investigation" }));
    expect(await screen.findByRole("table", { name: /die_bin \(category\).*W-1/ })).toBeInTheDocument();
  });
});
