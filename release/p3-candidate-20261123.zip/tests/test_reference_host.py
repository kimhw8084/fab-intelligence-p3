import hashlib
import importlib.util
import json
import os
import threading
import time
import unittest
from http.client import HTTPConnection
from http.server import ThreadingHTTPServer
from pathlib import Path
from unittest.mock import patch

from fabintel.reference_host import _Handler


@unittest.skipUnless(importlib.util.find_spec("mcp"), "install the local hash-locked MCP SDK candidate to run host acceptance")
class ReferenceHostAcceptanceTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.server = ThreadingHTTPServer(("127.0.0.1", 0), _Handler)
        cls.server.daemon_threads = True
        cls.thread = threading.Thread(target=cls.server.serve_forever, daemon=True)
        cls.thread.start()
        cls.port = cls.server.server_address[1]

    @classmethod
    def tearDownClass(cls):
        cls.server.shutdown()
        cls.server.server_close()
        cls.thread.join(timeout=2)

    def request(self, method, path, body=None, headers=None, timeout=20):
        connection = HTTPConnection("127.0.0.1", self.port, timeout=timeout)
        payload = None if body is None else json.dumps(body)
        request_headers = {"Content-Type": "application/json"} if payload is not None else {}
        request_headers.update(headers or {})
        connection.request(method, path, payload, request_headers)
        response = connection.getresponse()
        result = response.status, response.read(), dict(response.getheaders())
        connection.close()
        return result

    def test_host_serves_local_assets_and_health_without_remote_resources(self):
        status, body, headers = self.request("GET", "/api/health")
        self.assertEqual(status, 200)
        self.assertEqual(json.loads(body)["network"], "not used for synthetic mode")
        self.assertIn("no-store", headers["Cache-Control"])
        status, html, _headers = self.request("GET", "/")
        self.assertEqual(status, 200)
        self.assertIn(b"Spatial &amp; Yield", html)
        status, _js, js_headers = self.request("GET", "/assets/placeholder.js")
        self.assertEqual(status, 404)
        self.assertIn("default-src 'self'", js_headers["Content-Security-Policy"])

    def test_full_sdk_workflow_returns_typed_map_c01_to_c05_and_hashable_evidence(self):
        status, body, headers = self.request("POST", "/api/investigate", {
            "source_mode": "synthetic", "plan_ids": ["SYN-WF-CURRENT", "SYN-WF-PREVIOUS", "SYN-WF-BASELINE",
                                                          "SYN-WF-HISTORY", "SYN-WF-ASSOCIATION"],
            "time_start": "2026-01-01T00:00:00Z", "time_end": "2026-02-01T00:00:00Z", "top_k": 5,
        }, {"X-Analysis-Id": "624b7a32-a9c9-46c5-8745-818d2f000001"})
        self.assertEqual(status, 200, body.decode())
        self.assertIn("no-store", headers["Cache-Control"])
        module = json.loads(body)
        self.assertEqual(module["contract_version"], "p3-reference-module.v2")
        self.assertEqual(module["capabilities"], ["C01", "C02", "C03", "C04", "C05"])
        self.assertEqual(module["evidence"]["mode"], "SYNTHETIC_DEMO")
        result = module["evidence"]["artifacts"][0]["result"]
        self.assertEqual({key: result[key]["status"] for key in
                          ("fingerprint", "evolution", "quality_association", "anomaly", "similarity")},
                         {"fingerprint": "VALID", "evolution": "VALID", "quality_association": "VALID",
                          "anomaly": "VALID", "similarity": "VALID"})
        spatial = module["spatial_map"]
        import jsonschema
        schema = json.loads((Path(__file__).resolve().parents[1] / "products" / "p3" / "contracts" / "spatial-map.v2.schema.json").read_text(encoding="utf-8"))
        jsonschema.Draft202012Validator(schema).validate(spatial)
        self.assertEqual(spatial["schema_version"], "fab-spatial-map.v2")
        self.assertEqual(spatial["sampling"]["observation_count"], len(spatial["observations"]))
        self.assertEqual([row["value"] for row in spatial["observations"]], [10, 12, 12, 12, 12])
        self.assertEqual(len(module["evidence"]["provenance"]["mcp_workflow"]["bounded_reads"]), 5)
        canonical = module["export"]["canonical_json"].encode("utf-8")
        self.assertEqual(hashlib.sha256(canonical).hexdigest(), module["export"]["sha256"])
        self.assertEqual(json.loads(canonical)["contract_version"], "p3-reference-module.v2")

    def test_categorical_missing_and_defect_modalities_survive_the_host_and_v2_schema(self):
        import jsonschema
        schema = json.loads((Path(__file__).resolve().parents[1] / "products" / "p3" / "contracts" / "spatial-map.v2.schema.json").read_text(encoding="utf-8"))
        request = {"source_mode": "synthetic", "plan_ids": ["SYN-WF-CURRENT"]}
        cases = (("typed-categorical", ["PASS", 2, "FAIL", "PASS", 3]),
                 ("explicit-missing", [10, None, 12, 12, 12]),
                 ("typed-defect", ["BRIDGE", 7, None, None, None]))
        for scenario, expected_values in cases:
            with self.subTest(scenario=scenario), patch.dict(os.environ, {"FABINTEL_SYNTHETIC_SCENARIO": scenario}):
                status, body, _headers = self.request("POST", "/api/investigate", request)
            self.assertEqual(status, 200, body.decode())
            module = json.loads(body)
            spatial = module["spatial_map"]
            jsonschema.Draft202012Validator(schema).validate(spatial)
            observations = spatial["observations"]
            self.assertEqual([item["value"] for item in observations], expected_values)
            self.assertEqual(len(observations), spatial["sampling"]["observation_count"])
            if scenario == "typed-categorical":
                self.assertEqual(spatial["sampling"]["categorical_measurement_count"], 5)
                self.assertEqual(type(observations[1]["value"]), int)
                self.assertEqual(module["suite_compatibility"]["status"], "COMPATIBLE")
            elif scenario == "explicit-missing":
                self.assertEqual(spatial["sampling"]["explicit_missing_value_count"], 1)
                self.assertEqual(observations[1]["observation_kind"], "MISSING_MEASUREMENT")
            else:
                self.assertEqual(spatial["sampling"]["defect_event_count"], 5)
                self.assertEqual(spatial["sampling"]["explicit_missing_value_count"], 0)
                self.assertEqual(observations[2]["observation_kind"], "DEFECT_EVENT")
                self.assertEqual(module["suite_compatibility"]["status"], "UNREPRESENTABLE_WITHOUT_LOSS")

    def test_configured_mode_without_site_configuration_is_refused(self):
        with patch.dict(os.environ, {"FABINTEL_MCP_CONFIG": ""}):
            status, body, _headers = self.request("POST", "/api/investigate", {
                "source_mode": "configured", "plan_ids": ["SITE-APPROVED-PLAN"],
            })
        self.assertEqual(status, 403)
        self.assertEqual(json.loads(body)["status"], "REFUSED")

    def test_peer_permission_denial_and_stale_semantics_fail_closed(self):
        request = {"source_mode": "synthetic", "plan_ids": ["SYN-WF-CURRENT"]}
        with patch.dict(os.environ, {"FABINTEL_SYNTHETIC_SCENARIO": "read-denied"}):
            status, body, _headers = self.request("POST", "/api/investigate", request)
        self.assertEqual(status, 403)
        self.assertEqual(json.loads(body)["status"], "REFUSED")
        with patch.dict(os.environ, {"FABINTEL_SYNTHETIC_SCENARIO": "stale-semantics"}):
            status, body, _headers = self.request("POST", "/api/investigate", request)
        self.assertEqual(status, 422)
        self.assertEqual(json.loads(body)["status"], "REFUSED")

    def test_http_cancellation_stops_the_sdk_read_without_partial_success(self):
        request_id = "6c8690f0-906d-46a5-a63f-e380a8b00002"
        result = []
        worker = threading.Thread(target=lambda: result.append(self.request("POST", "/api/investigate", {
            "source_mode": "synthetic", "plan_ids": ["SYN-WF-CURRENT-CANCEL"],
        }, {"X-Analysis-Id": request_id}, timeout=8)))
        worker.start()
        deadline = time.monotonic() + 3
        from fabintel import reference_host
        while request_id not in reference_host._ACTIVE and time.monotonic() < deadline:
            time.sleep(0.01)
        self.assertIn(request_id, reference_host._ACTIVE)
        status, body, _headers = self.request("POST", "/api/cancel", {"request_id": request_id})
        self.assertEqual(status, 202)
        self.assertEqual(json.loads(body)["status"], "CANCEL_REQUESTED")
        worker.join(timeout=9)
        self.assertFalse(worker.is_alive())
        self.assertEqual(result[0][0], 409)
        self.assertEqual(json.loads(result[0][1])["status"], "CANCELLED")

    def test_cross_origin_and_unbounded_requests_are_rejected(self):
        request = {"source_mode": "synthetic", "plan_ids": ["SYN-WF-CURRENT"]}
        status, body, _headers = self.request("POST", "/api/investigate", request,
                                               {"Origin": "https://attacker.invalid", "Sec-Fetch-Site": "cross-site"})
        self.assertEqual(status, 403)
        self.assertIn("cross-origin", json.loads(body)["error"])
        status, body, _headers = self.request("POST", "/api/investigate", {**request, "plan_ids": ["X"] * 11})
        self.assertEqual(status, 400)
        self.assertIn("bounded limits", json.loads(body)["error"])


if __name__ == "__main__":
    unittest.main()
