# P3 implementation decisions

## D-001 · Keep scientific analysis standard-library only

Use Python's standard library for the deterministic P3 scientific baseline and JSON CLI. The former loopback API is test-fixture-only; the product UI is a headless P1-hosted React module. The current scientific methods operate on measured points and exact coordinate matches; they do not need image interpolation, model training, a database, or a service framework. MCP protocol behavior is supplied by an optional, pinned official SDK candidate; it does not enter the scientific runtime by default. Reopen scientific dependencies only if the frozen challenge suite identifies a concrete capability or performance gap.

## D-002 · Treat the measured-site mask as part of the data

Every numeric fingerprint is computed from supplied observations only. Missing center/edge coverage produces an inconclusive edge-center measure. C02 requires exact matched observed coordinates after the declared rotation unless a single pair uses a declared exact common-site policy with sufficient measured overlap. C05 compares exact sites where available and otherwise uses shared radial/sector profile bins; neither capability interpolates or registers arbitrary transforms. C01 reports robust radial regions and orientation-aware sectors, a least-squares directional plane, and exploratory fixed-grid local-cell clusters where geometry is known. The local-cell threshold is not calibrated. Reticle periodicity stays `NOT_COMPUTED` until reticle geometry and sampling-alias checks exist.

## D-003 · C04 uses a wafer-level max-T rank screen

C04 requires at least 20 earlier, distinct baseline lots and compatible metric, layer, product, population signature, geometry and sampling mask; the target lot is held out. Site robust scores are summarized by a leave-one-wafer-out maximum statistic, preserving the observed within-wafer dependence and controlling the search over sites with a rank p-value. Sites can localize a wafer-level alert but are not individually significant. The finite empirical p-value resolution is reported. Synthetic correlated-null simulations are a regression check, not production false-alert calibration or causal evidence.

## D-004 · C05 ranks multiscale shape without claiming mechanism

C05 combines centered exact-site RMSE with radial-profile and sector-profile distances. Exact values are compared only when observed coordinates match; different sampling masks may use shared radial/sector profile bins only when the minimum of two radial and four sector bins is met. There is no interpolation. It separately reports raw RMSE and mean-level difference, and excludes the target wafer and lot, future records, and incompatible definitions or geometry. The bounded in-memory index stores a validated snapshot and is checked against direct search. Retrieval quality and useful-neighbor relevance still need independent blinded fab review.

## D-005 · C02 requires same-wafer temporal evidence

C02 requires same wafer and lot, distinct step instances, increasing timezone-aware measurement times, equal product/metric/definition/unit/layer, matching population metadata, verified orientation, and identical observed coordinate sets after rotation. A pair of maps with different sampling masks may use `exact_common_site_v1` only when the policy was predeclared and both maps meet the configured site-count and coverage minimums. It accepts an ordered series of exact-layout steps, reports signed site deltas and same-direction persistence, records missing repeatability/transform uncertainty, and emits no unobserved values.

## D-006 · C03 uses wafer as the independent unit

C03 pairs the feature and later outcome at the selected map's exact observed die coordinates, applies fixed spatial-block centering within each wafer, then summarizes wafer-level correlations across holdout wafers with an equal-wafer Fisher-z interval. It requires at least 20 holdout wafers from distinct lots and five matched die sites per wafer, including at least two observations in each of two predeclared spatial blocks. The relation, block mapping, time ordering and out-of-time split grouped by both wafer and lot must be verified at the site. Where the selected map carries recipe, tool, chamber, or route identifiers, the downstream context and rows must match those identifiers. Leave-one-lot-out estimates are exposed as a sensitivity range. It reports association only; product mix, selection and other confounding remain.

## D-007 · Use official SDK transport; company authority remains site-side

The configurable client delegates MCP stdio and Streamable HTTP protocol behavior to the official Python SDK `mcp==2.3.0`; the product contains no custom JSON-RPC transport. Synthetic protocol peers and HTTP fixtures are test-only. The read-only adapter discovers tool descriptors and requires site-provided source grants, exact descriptor hashes, semantic versions and registered query-plan approvals before bounded reads. No company endpoint, tool mapping, credential, source grant or real semantics are included. Analysis has no model path. JSON inputs that request `INTERNAL_AUTHORIZED` are refused. The internal preflight consumes a site-generated logical-operation capture using the packaged contract names, lists missing evidence, and always retains `PENDING_INTERNAL`; it cannot authenticate company authority or grant approval.

## Known work still open

The algorithm thresholds and population assumptions require holdout qualification on representative approved data. Reticle periodicity scores require a traceable alias review and remain exploratory; local-cell clusters are not calibrated for alerting. Arbitrary registration, confound adjustment beyond the predeclared block effect, independent retrieval relevance, real task-study thresholds, actual company semantic/query-plan approval, target-OS air-gap install, license/rights approval, and signed independent audit remain release gates.
